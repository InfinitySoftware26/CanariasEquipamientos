import { Injectable } from "@nestjs/common";
import { InjectRepository } from "@nestjs/typeorm";
import { Repository } from "typeorm";

import { RouteSheetItem } from "../entities/route-sheet-item.entity";
import { IRouteSheetItemsRepository } from "../interfaces/route-sheet-items-repository.interface";
import { RouteSheetItemResult } from "../../../common/enums/route-sheet-item-result.enum";

@Injectable()
export class RouteSheetItemsRepository
  implements IRouteSheetItemsRepository
{
  constructor(
    @InjectRepository(RouteSheetItem)
    private readonly repo: Repository<RouteSheetItem>,
  ) {}

  // ============================================================
  // OBTENER ITEMS DE UNA HOJA
  // ============================================================

  async findByRouteSheet(
    routeSheetId: string,
  ): Promise<RouteSheetItem[]> {
    if (!routeSheetId) {
      return [];
    }

    return this.repo.find({
      where: {
        routeSheetId,
      },
      order: {
        createdAt: "ASC",
      },
    });
  }

  // ============================================================
  // OBTENER ITEM POR ID
  // ============================================================

  async findById(
    id: string,
  ): Promise<RouteSheetItem | null> {
    if (!id) {
      return null;
    }

    return this.repo.findOne({
      where: {
        itemId: id,
      },
    });
  }

  // ============================================================
  // CREAR ITEMS
  // ============================================================

  async createMany(
    data: Partial<RouteSheetItem>[],
  ): Promise<RouteSheetItem[]> {
    if (!data.length) {
      return [];
    }

    const entities = data.map((item) =>
      this.repo.create(item),
    );

    return this.repo.save(entities);
  }

  // ============================================================
  // ACTUALIZAR RESULTADO
  // ============================================================

  async updateResult(
    id: string,
    result: RouteSheetItemResult,
    collectedAmount?: number,
    notes?: string,
  ): Promise<void> {
    if (!id) {
      return;
    }

    const updates: Partial<RouteSheetItem> = {
      result,
      visitedAt: new Date(),
    };

    if (collectedAmount !== undefined) {
      updates.collectedAmount = collectedAmount;
    }

    if (notes !== undefined) {
      updates.notes = notes;
    }

    await this.repo.update(
      {
        itemId: id,
      },
      updates,
    );
  }
}
