import {
  Injectable,
  Inject,
  NotFoundException,
  ConflictException,
  ForbiddenException,
  UnauthorizedException,
} from "@nestjs/common";
import * as bcrypt from "bcrypt";
import {
  IStaffRepository,
  STAFF_REPOSITORY,
} from "../interfaces/staff-repository.interface";
import { CreateStaffDto } from "../dto/create-staff.dto";
import { CreateSuperAdminDto } from "../dto/create-super-admin.dto";
import { UpdateStaffDto } from "../dto/update-staff.dto";
import { ChangePasswordDto } from "../dto/change-password.dto";
import { Staff } from "../entities/staff.entity";
import { StaffRole } from "../../../common/enums/staff-role.enum";
import { JwtPayload } from "../../../common/interfaces/jwt-payload.interface";
import { SocietiesService } from "../../societies/services/societies.service";

const SALT_ROUNDS = 12;

/**
 * Mapa de permisos de creacion por rol.
 * SUPER_ADMIN puede crear cualquier rol incluyendo otro SUPER_ADMIN
 * (via endpoint exclusivo POST /staff/super-admin).
 * OCP: agregar un nuevo rol solo requiere actualizar este mapa.
 */
const CREATION_PERMISSIONS: Readonly<Record<string, StaffRole[]>> = {
  [StaffRole.SUPER_ADMIN]: [
    StaffRole.SUPER_ADMIN,
    StaffRole.MANAGER,
    StaffRole.ADMIN,
    StaffRole.SELLER,
    StaffRole.COLLECTOR,
  ],
  [StaffRole.MANAGER]: [StaffRole.ADMIN, StaffRole.SELLER, StaffRole.COLLECTOR],
  [StaffRole.ADMIN]: [StaffRole.SELLER, StaffRole.COLLECTOR],
};

@Injectable()
export class StaffService {
  constructor(
    @Inject(STAFF_REPOSITORY)
    private readonly staffRepo: IStaffRepository,
    private readonly societiesService: SocietiesService,
  ) {}

  // ─── QUERIES ──────────────────────────────────────────────────────────────

  findAll(societyId: string): Promise<Staff[]> {
    return this.staffRepo.findAll(societyId);
  }

  async findById(id: string): Promise<Staff> {
    const staff = await this.staffRepo.findById(id);
    if (!staff)
      throw new NotFoundException("Empleado " + id + " no encontrado");
    return staff;
  }

  getProfile(currentUser: JwtPayload): Promise<Staff> {
    return this.findById(currentUser.sub);
  }

  findByEmailWithPassword(email: string): Promise<Staff | null> {
    return this.staffRepo.findByEmailWithPassword(email);
  }

  async lookup(
    currentSocietyId: string,
    email?: string,
    dni?: string,
  ): Promise<(Staff & { alreadyInCurrentSociety: boolean }) | null> {
    if (!email && !dni) return null;

    const found = email
      ? await this.staffRepo.findByEmail(email)
      : await this.staffRepo.findByDni(dni!);

    if (!found) return null;

    const societies = await this.societiesService.getSocietiesForStaff(
      found.staffId,
    );
    const alreadyInCurrentSociety = societies.some(
      (s) => s.societyId === currentSocietyId,
    );

    return { ...found, alreadyInCurrentSociety };
  }

  // ─── COMMANDS ─────────────────────────────────────────────────────────────

  /**
   * Crea un empleado con rol asignable (MANAGER, ADMIN, SELLER, COLLECTOR).
   * El rol SUPER_ADMIN no puede ser enviado por este metodo.
   */
  async create(dto: CreateStaffDto, currentUser: JwtPayload): Promise<Staff> {
    this.assertCanCreateRole(
      currentUser.role,
      dto.role as unknown as StaffRole,
    );
    await this.assertUniqueEmailAndDni(dto.email, dto.dni);

    const passwordHash = await bcrypt.hash(dto.password, SALT_ROUNDS);

    // SUPER_ADMIN puede asignar a cualquier sociedad; los demás roles solo
    // pueden crear staff en su propia sociedad (ignoramos dto.societyId)
    const primarySocietyId =
      currentUser.role === StaffRole.SUPER_ADMIN
        ? dto.societyId
        : currentUser.societyId;

    const staff = await this.staffRepo.create({
      name: dto.name,
      dni: dto.dni,
      email: dto.email,
      phone: dto.phone,
      passwordHash,
      role: dto.role as unknown as StaffRole,
      primarySocietyId,
      isActive: true,
    });

    if (primarySocietyId) {
      await this.societiesService.linkStaffToSociety(
        staff.staffId,
        primarySocietyId,
      );
    }

    return staff;
  }

  /**
   * Crea un SUPER_ADMIN.
   * Solo accesible por otro SUPER_ADMIN via POST /staff/super-admin.
   */
  async createSuperAdmin(
    dto: CreateSuperAdminDto,
    currentUser: JwtPayload,
  ): Promise<Staff> {
    this.assertCanCreateRole(currentUser.role, StaffRole.SUPER_ADMIN);
    await this.assertUniqueEmailAndDni(dto.email, dto.dni);

    const passwordHash = await bcrypt.hash(dto.password, SALT_ROUNDS);

    return this.staffRepo.create({
      name: dto.name,
      dni: dto.dni,
      email: dto.email,
      phone: dto.phone,
      passwordHash,
      role: StaffRole.SUPER_ADMIN,
      primarySocietyId: dto.societyId ?? undefined,
      isActive: true,
    });
  }

  async update(
    id: string,
    dto: UpdateStaffDto,
    currentUser: JwtPayload,
  ): Promise<Staff> {
    await this.assertCanUpdate(id, dto, currentUser);
    return this.staffRepo.update(id, dto);
  }

  async changePassword(
    id: string,
    dto: ChangePasswordDto,
    currentUser: JwtPayload,
  ): Promise<void> {
    if (currentUser.sub !== id) {
      throw new ForbiddenException("Solo puedes cambiar tu propia contrasena");
    }

    const staff = await this.staffRepo.findByEmailWithPassword(
      (await this.findById(id)).email,
    );
    if (!staff) throw new NotFoundException("Empleado no encontrado");

    const isMatch = await bcrypt.compare(
      dto.currentPassword,
      staff.passwordHash,
    );
    if (!isMatch)
      throw new UnauthorizedException("La contrasena actual es incorrecta");

    const newHash = await bcrypt.hash(dto.newPassword, SALT_ROUNDS);
    await this.staffRepo.updatePassword(id, newHash);
  }

  async deactivate(id: string): Promise<void> {
    await this.findById(id);
    await this.staffRepo.update(id, { isActive: false });
  }

  // ─── GUARDS DE NEGOCIO ────────────────────────────────────────────────────

  private assertCanCreateRole(
    creatorRole: string,
    targetRole: StaffRole,
  ): void {
    const allowed = CREATION_PERMISSIONS[creatorRole] ?? [];
    if (!allowed.includes(targetRole)) {
      throw new ForbiddenException(
        "No tienes permiso para crear usuarios con el rol " + targetRole,
      );
    }
  }

  private async assertUniqueEmailAndDni(
    email: string,
    dni: string,
  ): Promise<void> {
    const [byEmail, byDni] = await Promise.all([
      this.staffRepo.findByEmail(email),
      this.staffRepo.findByDni(dni),
    ]);
    if (byEmail)
      throw new ConflictException("El email " + email + " ya esta registrado");
    if (byDni)
      throw new ConflictException("El DNI " + dni + " ya esta registrado");
  }

  private async assertCanUpdate(
    targetId: string,
    dto: UpdateStaffDto,
    currentUser: JwtPayload,
  ): Promise<void> {
    const isSuperAdmin = currentUser.role === StaffRole.SUPER_ADMIN;
    const isManager = currentUser.role === StaffRole.MANAGER;
    const isAdmin = currentUser.role === StaffRole.ADMIN;
    const isSelf = currentUser.sub === targetId;

    const target = await this.findById(targetId);
    if (
      (dto.role !== undefined || dto.isActive !== undefined) &&
      !isSuperAdmin &&
      !isManager &&
      !isAdmin
    ) {
      throw new ForbiddenException(
        "No tienes permiso para cambiar el rol o estado",
      );
    }

    if (
      isAdmin &&
      !isSelf &&
      target.role !== StaffRole.SELLER &&
      target.role !== StaffRole.COLLECTOR
    ) {
      throw new ForbiddenException(
        "Solo puedes editar vendedores y cobradores",
      );
    }

    if (!isSuperAdmin && !isManager && !isAdmin && !isSelf) {
      throw new ForbiddenException(
        "No tienes permiso para editar este empleado",
      );
    }
  }
}
