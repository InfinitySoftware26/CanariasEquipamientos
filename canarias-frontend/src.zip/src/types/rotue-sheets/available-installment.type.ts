export interface AvailableRouteInstallment {
  installmentId: string;

  installmentNumber: number;

  amount: number;

  dueDate: string;

  status: string;

  saleId: string;

  clientId: string;

  clientName: string;

  clientDocumentNumber?: string | null;

  clientAddress?: string | null;

  clientPhone?: string | null;
}
